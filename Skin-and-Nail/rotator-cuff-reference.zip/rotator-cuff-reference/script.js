// Rotator Cuff Clinical Reference - JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initSmoothScroll();
    initActiveNavHighlight();
    initCardAnimations();
    initExpandableContent();
    initSearchFunctionality();
    initPrintFunctionality();
    initHoverEffects();
});

// Smooth scrolling for navigation links
function initSmoothScroll() {
    const navLinks = document.querySelectorAll('.quick-nav a[href^="#"]');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);

            if (targetSection) {
                const headerOffset = 100;
                const elementPosition = targetSection.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });

                // Update URL without jumping
                history.pushState(null, null, targetId);
            }
        });
    });
}

// Highlight active navigation item based on scroll position
function initActiveNavHighlight() {
    const sections = document.querySelectorAll('section[id]');
    const navItems = document.querySelectorAll('.quick-nav .nav-item');

    function highlightNavItem() {
        const scrollPosition = window.scrollY + 150;

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('href') === `#${sectionId}`) {
                        item.classList.add('active');
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', throttle(highlightNavItem, 100));
    highlightNavItem(); // Initial check
}

// Animate cards on scroll
function initCardAnimations() {
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe all cards
    document.querySelectorAll('.card, .test-card, .imaging-card, .case-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(card);
    });
}

// Initialize expandable content sections
function initExpandableContent() {
    const expandableHeaders = document.querySelectorAll('.card h3, .test-header');

    expandableHeaders.forEach(header => {
        header.style.cursor = 'pointer';
        header.addEventListener('click', function() {
            const content = this.nextElementSibling;
            if (content && content.classList.contains('expandable')) {
                toggleExpand(content);
            }
        });
    });
}

// Toggle expandable content
function toggleExpand(element) {
    const isExpanded = element.classList.contains('expanded');

    // Close all other expanded elements
    document.querySelectorAll('.expandable.expanded').forEach(item => {
        if (item !== element) {
            item.classList.remove('expanded');
            item.style.maxHeight = '0';
            item.style.overflow = 'hidden';
            item.style.transition = 'max-height 0.3s ease';
        }
    });

    // Toggle current element
    if (isExpanded) {
        element.classList.remove('expanded');
        element.style.maxHeight = '0';
    } else {
        element.classList.add('expanded');
        element.style.maxHeight = element.scrollHeight + 'px';
        element.style.overflow = 'hidden';
        element.style.transition = 'max-height 0.3s ease';
    }
}

// Search functionality
function initSearchFunctionality() {
    // Add search bar to header if not present
    const headerContent = document.querySelector('.header-content');

    const searchContainer = document.createElement('div');
    searchContainer.className = 'search-container';
    searchContainer.innerHTML = `
        <div class="search-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"/>
                <path d="M21 21l-4.35-4.35"/>
            </svg>
            <input type="text" id="searchInput" placeholder="Search symptoms, tests, treatments...">
        </div>
    `;

    // Insert after header content
    headerContent.parentNode.insertBefore(searchContainer, headerContent.nextSibling);

    // Add search styles
    const searchStyles = document.createElement('style');
    searchStyles.textContent = `
        .search-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            margin-top: 16px;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 12px;
            background: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .search-box svg {
            width: 20px;
            height: 20px;
            color: #6c757d;
        }
        .search-box input {
            flex: 1;
            border: none;
            outline: none;
            font-size: 15px;
            color: #212529;
        }
        .search-box input::placeholder {
            color: #adb5bd;
        }
        .highlight {
            background-color: #fff3cd;
            padding: 2px 4px;
            border-radius: 2px;
        }
    `;
    document.head.appendChild(searchStyles);

    // Search functionality
    const searchInput = document.getElementById('searchInput');

    searchInput.addEventListener('input', debounce(function(e) {
        const searchTerm = e.target.value.toLowerCase().trim();

        if (searchTerm.length < 2) {
            clearHighlights();
            return;
        }

        highlightSearchTerm(searchTerm);
    }, 300));

    // Clear highlights on escape
    searchInput.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            this.value = '';
            clearHighlights();
            this.blur();
        }
    });
}

// Highlight search terms in content
function highlightSearchTerm(term) {
    clearHighlights();

    const searchableElements = document.querySelectorAll('p, li, td, th, h4, h3');

    searchableElements.forEach(element => {
        const text = element.textContent;
        if (text.toLowerCase().includes(term)) {
            // Skip if element already highlighted
            if (element.closest('.highlight')) return;

            const regex = new RegExp(`(${escapeRegex(term)})`, 'gi');
            const highlightedText = text.replace(regex, '<span class="highlight">$1</span>');
            element.innerHTML = highlightedText;
        }
    });
}

// Clear all highlights
function clearHighlights() {
    document.querySelectorAll('.highlight').forEach(el => {
        const parent = el.parentNode;
        parent.replaceChild(document.createTextNode(el.textContent), el);
        parent.normalize();
    });
}

// Print functionality
function initPrintFunctionality() {
    // Add print button
    const headerRight = document.querySelector('.header-right');

    const printButton = document.createElement('button');
    printButton.className = 'print-button';
    printButton.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 6 2 18 2 18 9"/>
            <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
            <rect x="6" y="14" width="12" height="8"/>
        </svg>
        Print
    `;

    // Add print styles
    const printStyles = document.createElement('style');
    printStyles.textContent = `
        .print-button {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(76, 201, 240, 0.2);
            color: #4cc9f0;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-left: 12px;
        }
        .print-button:hover {
            background: rgba(76, 201, 240, 0.3);
        }
        .print-button svg {
            width: 18px;
            height: 18px;
        }
        @media print {
            .print-button, .search-container, .quick-nav {
                display: none !important;
            }
            .header {
                background: #1a1a2e !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .section-header {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .card {
                break-inside: avoid;
            }
        }
    `;
    document.head.appendChild(printStyles);

    headerRight.appendChild(printButton);

    printButton.addEventListener('click', function() {
        window.print();
    });
}

// Enhanced hover effects
function initHoverEffects() {
    // Add ripple effect to buttons
    document.querySelectorAll('.nav-item, .print-button, .option-tag').forEach(button => {
        button.addEventListener('mouseenter', function(e) {
            this.style.transform = 'translateY(-2px)';
        });

        button.addEventListener('mouseleave', function(e) {
            this.style.transform = 'translateY(0)';
        });
    });

    // Add staggered animation to timeline items
    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 0.1}s`;
    });

    // Add hover effect to table rows
    document.querySelectorAll('.differential-table tbody tr').forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.01)';
            this.style.transition = 'transform 0.2s ease';
        });

        row.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });

    // Add animation to alert badges
    document.querySelectorAll('.alert-badge.critical').forEach(badge => {
        badge.addEventListener('mouseenter', function() {
            this.style.animation = 'pulse 1s infinite';
        });

        badge.addEventListener('mouseleave', function() {
            this.style.animation = 'pulse 2s infinite';
        });
    });
}

// Utility: Throttle function
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Utility: Debounce function
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

// Utility: Escape regex special characters
function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Add keyboard navigation
document.addEventListener('keydown', function(e) {
    // Navigate with arrow keys when not in input
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
        const sections = document.querySelectorAll('section[id]');
        const currentScroll = window.scrollY;

        if (e.key === 'ArrowDown' || e.key === 'PageDown') {
            e.preventDefault();
            const nextSection = findNextSection(sections, currentScroll);
            if (nextSection) {
                nextSection.scrollIntoView({ behavior: 'smooth' });
            }
        } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
            e.preventDefault();
            const prevSection = findPrevSection(sections, currentScroll);
            if (prevSection) {
                prevSection.scrollIntoView({ behavior: 'smooth' });
            }
        }
    }
});

// Find next section for keyboard navigation
function findNextSection(sections, currentScroll) {
    for (let i = 0; i < sections.length; i++) {
        if (sections[i].offsetTop > currentScroll + 100) {
            return sections[i];
        }
    }
    return sections[sections.length - 1];
}

// Find previous section for keyboard navigation
function findPrevSection(sections, currentScroll) {
    for (let i = sections.length - 1; i >= 0; i--) {
        if (sections[i].offsetTop < currentScroll - 100) {
            return sections[i];
        }
    }
    return sections[0];
}

// Add tooltips to complex terms
document.querySelectorAll('.tendon-tag').forEach(tag => {
    tag.setAttribute('title', 'Click for more information about this tendon');
    tag.style.cursor = 'help';
});

// Initialize tooltip hover
document.querySelectorAll('[title]').forEach(element => {
    element.addEventListener('mouseenter', function(e) {
        const tooltip = document.createElement('div');
        tooltip.className = 'custom-tooltip';
        tooltip.textContent = this.getAttribute('title');
        document.body.appendChild(tooltip);

        const rect = this.getBoundingClientRect();
        tooltip.style.position = 'fixed';
        tooltip.style.left = `${rect.left + rect.width / 2 - tooltip.offsetWidth / 2}px`;
        tooltip.style.top = `${rect.bottom + 8}px`;
        tooltip.style.background = '#212529';
        tooltip.style.color = 'white';
        tooltip.style.padding = '6px 12px';
        tooltip.style.borderRadius = '4px';
        tooltip.style.fontSize = '12px';
        tooltip.style.zIndex = '1000';
        tooltip.style.opacity = '0';
        tooltip.style.transition = 'opacity 0.2s ease';

        this.setAttribute('data-tooltip-id', 'tooltip');

        setTimeout(() => {
            tooltip.style.opacity = '1';
        }, 10);

        this._tooltip = tooltip;
    });

    element.addEventListener('mouseleave', function() {
        if (this._tooltip) {
            this._tooltip.style.opacity = '0';
            setTimeout(() => {
                if (this._tooltip.parentNode) {
                    this._tooltip.parentNode.removeChild(this._tooltip);
                }
            }, 200);
        }
    });
});