const { chromium } = require('playwright');
const path = require('path');

async function testPage() {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();

    // Collect console errors
    const consoleErrors = [];
    page.on('console', msg => {
        if (msg.type() === 'error') {
            consoleErrors.push(msg.text());
        }
    });

    page.on('pageerror', error => {
        consoleErrors.push(error.message);
    });

    try {
        // Load the page
        const filePath = path.join(__dirname, 'index.html');
        await page.goto(`file://${filePath}`, { waitUntil: 'networkidle' });

        // Wait for page to be fully loaded
        await page.waitForTimeout(1000);

        // Check if main elements exist
        const header = await page.$('.header');
        const nav = await page.$('.quick-nav');
        const mainContent = await page.$('.main-content');
        const sections = await page.$$('section');

        console.log('=== Page Load Test Results ===');
        console.log(`Header exists: ${!!header}`);
        console.log(`Navigation exists: ${!!nav}`);
        console.log(`Main content exists: ${!!mainContent}`);
        console.log(`Number of sections: ${sections.length}`);

        // Check for specific sections
        const sectionIds = await page.$$eval('section[id]', sections => sections.map(s => s.id));
        console.log(`Sections found: ${sectionIds.join(', ')}`);

        // Report console errors
        if (consoleErrors.length > 0) {
            console.log('\n=== Console Errors ===');
            consoleErrors.forEach((error, i) => {
                console.log(`${i + 1}. ${error}`);
            });
        } else {
            console.log('\n=== No console errors detected ===');
        }

        // Test interactivity
        const navItems = await page.$$('.nav-item');
        console.log(`\nNavigation items: ${navItems.length}`);

        // Check card counts
        const cards = await page.$$('.card');
        console.log(`Total cards: ${cards.length}`);

        console.log('\n=== Test Complete ===');
        console.log(consoleErrors.length === 0 ? 'SUCCESS: Page loaded without errors' : 'FAILED: Console errors detected');

    } catch (error) {
        console.error('Test failed:', error.message);
    } finally {
        await browser.close();
    }
}

testPage();